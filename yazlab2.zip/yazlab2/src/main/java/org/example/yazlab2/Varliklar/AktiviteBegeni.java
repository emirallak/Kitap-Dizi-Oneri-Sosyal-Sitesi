package org.example.yazlab2. Varliklar;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "aktivite_begeni", uniqueConstraints = @UniqueConstraint(columnNames = {"aktivite_id", "kullanici_id"}))
public class AktiviteBegeni
{
    @Id
    @GeneratedValue(strategy = GenerationType. IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "aktivite_id", nullable = false)
    private KullaniciIcerik aktivite;

    @ManyToOne
    @JoinColumn(name = "kullanici_id", nullable = false)
    private Kullanici kullanici;

    @Column(nullable = false)
    private LocalDateTime tarih;


    public AktiviteBegeni()
    {

        this.tarih = LocalDateTime.now();
    }

    public AktiviteBegeni(KullaniciIcerik aktivite, Kullanici kullanici)
    {
        this.aktivite = aktivite;
        this. kullanici = kullanici;
        this.tarih = LocalDateTime.now();
    }

    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public KullaniciIcerik getAktivite()
    {
        return aktivite;
    }
    public void setAktivite(KullaniciIcerik aktivite)
    {
        this.aktivite = aktivite;
    }

    public Kullanici getKullanici()
    {
        return kullanici;
    }

    public void setKullanici(Kullanici kullanici)
    {
        this.kullanici = kullanici;
    }

    public LocalDateTime getTarih()
    {
        return tarih;
    }

    public void setTarih(LocalDateTime tarih)
    {
        this.tarih = tarih;
    }
}