package org.example.yazlab2. DTO;
import java.time.LocalDateTime;
import java. util.Locale;

public class AktiviteDTO
{

    private Long aktiviteId;
    private String kullaniciAdi;
    private String avatarUrl;
    private String icerikBaslik;
    private String posterUrl;
    private String tur;
    private String apiId;
    private String eylem;
    private Integer puan;
    private LocalDateTime tarih;
    private String yorumMetni;
    private long begeniSayisi;
    private boolean kullaniciBegenmis;


    public AktiviteDTO(Long aktiviteId, String kullaniciAdi, String avatarUrl, String icerikBaslik, String posterUrl, String tur, String apiId, String eylem, Integer puan, LocalDateTime tarih, String yorumMetni, long begeniSayisi, boolean kullaniciBegenmis) {
        this. aktiviteId = aktiviteId;
        this.kullaniciAdi = kullaniciAdi;
        this.avatarUrl = avatarUrl;
        this. icerikBaslik = icerikBaslik;
        this. posterUrl = posterUrl;
        this.tur = tur;
        this.apiId = apiId;
        this.eylem = eylem;
        this. puan = puan;
        this.tarih = tarih;
        this.yorumMetni = yorumMetni;
        this.begeniSayisi = begeniSayisi;
        this.kullaniciBegenmis = kullaniciBegenmis;
    }


    public Long getAktiviteId()
    {
        return aktiviteId;
    }
    public String getKullaniciAdi()
    {
        return kullaniciAdi;
    }
    public String getAvatarUrl()
    {
        return avatarUrl;
    }
    public String getIcerikBaslik()
    {
        return icerikBaslik;
    }
    public String getPosterUrl()
    {
        return posterUrl;
    }
    public String getTur()
    {
        return tur;
    }
    public String getApiId()
    {
        return apiId;
    }
    public String getEylem()
    {
        return eylem;
    }
    public Integer getPuan()
    {
        return puan;
    }
    public LocalDateTime getTarih()
    {
        return tarih;
    }
    public String getYorumMetni()
    {
        return yorumMetni;
    }
    public long getBegeniSayisi()
    {
        return begeniSayisi;
    }
    public boolean isKullaniciBegenmis()
    {
        return kullaniciBegenmis;
    }

    public String getDetayLink()
    {
        if (tur == null || apiId == null)
            return "#";
        String temizId = apiId.replace("FILM_", "").replace("KITAP_", "");
        String turKucuk = tur. toLowerCase(Locale.ENGLISH);
        return "/detay/" + turKucuk + "/" + temizId;
    }


    public String getEylemMetni()
    {
        if ("IZLENDI".equals(eylem))
            return "bir filmi izledi";
        if ("IZLENECEK".equals(eylem))
            return "bir filmi izlenecekler listesine ekledi";
        if ("OKUNDU".equals(eylem))
            return "bir kitabı okudu";
        if ("OKUNACAK".equals(eylem))
            return "bir kitabı okunacaklar listesine ekledi";
        if ("YORUM".equals(eylem))
            return "bir içerik hakkında yorum yaptı";
        return "bir etkileşimde bulundu";
    }

    public String getTarihFarki()
    {
        if (tarih == null) return "Bilinmiyor";
        return tarih.toString();
    }
}