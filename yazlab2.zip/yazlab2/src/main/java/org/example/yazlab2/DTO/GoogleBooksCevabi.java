package org.example.yazlab2.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GoogleBooksCevabi {


    private List<KitapDTO> items;

    public List<KitapDTO> getItems()
    {
        return items;
    }

    public void setItems(List<KitapDTO> items)
    {
        this.items = items;
    }
}