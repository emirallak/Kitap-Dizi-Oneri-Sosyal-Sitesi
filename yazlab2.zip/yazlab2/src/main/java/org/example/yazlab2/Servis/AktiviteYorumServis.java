package org.example.yazlab2.Servis;

import org.example.yazlab2.Depo.AktiviteYorumDepo;
import org.example.yazlab2.DTO.YorumDTO;
import org.example.yazlab2.Varliklar.AktiviteYorum;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AktiviteYorumServis
{

    private final AktiviteYorumDepo aktiviteYorumDepo;
    private final KullaniciIcerikServis kullaniciIcerikServis;

    public AktiviteYorumServis(AktiviteYorumDepo aktiviteYorumDepo, KullaniciIcerikServis kullaniciIcerikServis)
    {
        this.aktiviteYorumDepo = aktiviteYorumDepo;
        this.kullaniciIcerikServis = kullaniciIcerikServis;
    }


    @Transactional
    public void yorumKaydet(Long aktiviteId, Kullanici yorumuYapan, String yorumMetni)
    {
        KullaniciIcerik aktivite = kullaniciIcerikServis.aktiviteBul(aktiviteId);
        AktiviteYorum yorum = new AktiviteYorum();
        yorum.setAktivite(aktivite);
        yorum.setYorumuYapan(yorumuYapan);
        yorum.setYorumMetni(yorumMetni);
        aktiviteYorumDepo.save(yorum);
    }

    public List<YorumDTO> yorumlariGetir(KullaniciIcerik aktivite, String mevcutKullaniciAdi) {
        List<AktiviteYorum> yorumlar = aktiviteYorumDepo.findByAktiviteOrderByTarihAsc(aktivite);
        return yorumlar.stream().map(yorum -> new YorumDTO(yorum.getId(), yorum.getYorumuYapan().getKullaniciAdi(), yorum.getYorumMetni(), yorum.getTarih(), yorum.getYorumuYapan().getKullaniciAdi().equals(mevcutKullaniciAdi))).collect(Collectors.toList());
    }


    @Transactional
    public void yorumSil(Long yorumId, Kullanici kullanici) {
        AktiviteYorum yorum = aktiviteYorumDepo.findById(yorumId).orElseThrow(() -> new RuntimeException("Yorum bulunamadı!"));


        if (!yorum.getYorumuYapan().getId().equals(kullanici.getId()))
        {
            throw new SecurityException("Bu yorumu silme yetkiniz yok.");
        }
        aktiviteYorumDepo.delete(yorum);
    }
}