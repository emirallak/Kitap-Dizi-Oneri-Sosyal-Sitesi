package org.example.yazlab2.Kontroller;

import org.example.yazlab2.DTO.AktiviteDTO;
import org.example.yazlab2.DTO.YorumDTO;
import org.example.yazlab2.Servis.AktiviteServis;
import org.example.yazlab2.Servis.AktiviteYorumServis;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Servis.KullaniciIcerikServis;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class YorumGoster
{

    private final AktiviteServis aktiviteServis;
    private final AktiviteYorumServis aktiviteYorumServis;
    private final KullaniciServis kullaniciServis;
    private final KullaniciIcerikServis kullaniciIcerikServis;


    public YorumGoster(AktiviteServis aktiviteServis, AktiviteYorumServis aktiviteYorumServis, KullaniciServis kullaniciServis, KullaniciIcerikServis kullaniciIcerikServis)
    {
        this.aktiviteServis = aktiviteServis;
        this.aktiviteYorumServis = aktiviteYorumServis;
        this.kullaniciServis = kullaniciServis;
        this.kullaniciIcerikServis = kullaniciIcerikServis;
    }

    @GetMapping("/aktivite/yorum-sayfasi/{aktiviteId}")
    public String yorumSayfasiGet(@PathVariable("aktiviteId") Long aktiviteId, Authentication authentication, Model model)
    {
        KullaniciIcerik aktivite = kullaniciIcerikServis.aktiviteBul(aktiviteId);
        String mevcutKullaniciAdi = authentication.getName();
        Kullanici mevcutKullanici = kullaniciServis.kullaniciBul(mevcutKullaniciAdi);
        AktiviteDTO aktiviteDTO = aktiviteServis.mapKullaniciIcerikToAktiviteDTO(aktivite, mevcutKullanici);
        List<YorumDTO> yorumlar = aktiviteYorumServis.yorumlariGetir(aktivite, mevcutKullaniciAdi);
        model.addAttribute("aktivite", aktiviteDTO);
        model.addAttribute("aktiviteId", aktiviteId);
        model.addAttribute("yorumlar", yorumlar);
        return "yorum_detay";
    }


    @PostMapping("/aktivite/yorum-kaydet")
    public String yorumKaydet(@RequestParam("aktiviteId") Long aktiviteId,
                              @RequestParam("yorumMetni") String yorumMetni,
                              Authentication authentication) {
        try
        {
            Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());

            if (yorumMetni.trim().isEmpty())
            {
                return "redirect:/aktivite/yorum-sayfasi/" + aktiviteId;
            }

            aktiviteYorumServis.yorumKaydet(aktiviteId, kullanici, yorumMetni);


            return "redirect:/aktivite/yorum-sayfasi/" + aktiviteId + "?yorumEklendi=true";

        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/aktivite/yorum-sayfasi/" + aktiviteId + "?yorumHata=true";
        }
    }


    @PostMapping("/aktivite/yorum-sil/{yorumId}")
    public String yorumSil(@PathVariable("yorumId") Long yorumId, @RequestParam("aktiviteId") Long aktiviteId, Authentication authentication) {
        try
        {
            Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
            aktiviteYorumServis.yorumSil(yorumId, kullanici);

            return "redirect:/aktivite/yorum-sayfasi/" + aktiviteId + "?yorumSilindi=true";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/aktivite/yorum-sayfasi/" + aktiviteId + "?yorumHata=true";
        }
    }
}