package org.example.yazlab2.Varliklar;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "aktivite_yorum")
public class AktiviteYorum
{


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "aktivite_id", nullable = false)
    private KullaniciIcerik aktivite;

    @ManyToOne
    @JoinColumn(name = "kullanici_id", nullable = false)
    private Kullanici yorumuYapan;

    @Column(name = "yorum_metni", columnDefinition = "TEXT", nullable = false)
    private String yorumMetni;

    @Column(name = "tarih", nullable = false)
    private LocalDateTime tarih = LocalDateTime.now();


    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }
    public KullaniciIcerik getAktivite()
    {
        return aktivite;
    }
    public void setAktivite(KullaniciIcerik aktivite)
    {
        this.aktivite = aktivite;
    }
    public Kullanici getYorumuYapan()
    {
        return yorumuYapan;
    }
    public void setYorumuYapan(Kullanici yorumuYapan)
    {
        this.yorumuYapan = yorumuYapan;
    }
    public String getYorumMetni()
    {
        return yorumMetni;
    }
    public void setYorumMetni(String yorumMetni)
    {
        this.yorumMetni = yorumMetni;
    }
    public LocalDateTime getTarih()
    {
        return tarih;
    }
    public void setTarih(LocalDateTime tarih)
    {
        this.tarih = tarih;
    }
}