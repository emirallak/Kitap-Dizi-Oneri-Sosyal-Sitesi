package org.example.yazlab2.Kontroller;

import org.example.yazlab2.DTO.KitapDTO;
import org.example.yazlab2.Servis.EtkilesimServis;
import org.example.yazlab2.Servis.GoogleBooksServis;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Varliklar.Kullanici;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DetayKitap
{

    private final GoogleBooksServis googleBooksServis;
    private final EtkilesimServis etkilesimServis;
    private final KullaniciServis kullaniciServis;

    public DetayKitap(GoogleBooksServis googleBooksServis, EtkilesimServis etkilesimServis, KullaniciServis kullaniciServis) {
        this.googleBooksServis = googleBooksServis;
        this.etkilesimServis = etkilesimServis;
        this.kullaniciServis = kullaniciServis;
    }


    @GetMapping("/detay/kitap/{id}")
    public String kitapDetay(@PathVariable("id") String id, Model model, Authentication authentication)
    {
        KitapDTO kitap = googleBooksServis.kitapDetayGetir(id);
        if (kitap != null)
        {
            model.addAttribute("kitap", kitap);


            if (authentication != null)
            {
                String kullaniciAdi = authentication.getName();
                Kullanici kullanici = kullaniciServis.kullaniciBul(kullaniciAdi);

                String apiId = "KITAP_" + id;
                Integer kullaniciPuani = etkilesimServis.kullaniciPuaniGetir(kullanici, apiId);

                model.addAttribute("kullaniciPuani", kullaniciPuani);
            }
            return "detay_kitap";
        }
        return "redirect:/ara";
    }

    @PostMapping("/detay/kitap/ekle")
    public String kitapListeyeEkle(@RequestParam("kitapId") String kitapId, @RequestParam("durum") String durum, @RequestParam(value = "puan", required = false) Integer puan, Authentication authentication) {
        try
        {
            String kullaniciAdi = authentication.getName();
            Kullanici kullanici = kullaniciServis.kullaniciBul(kullaniciAdi);

            etkilesimServis.kitapListeyeEkle(kullanici, kitapId, durum, puan);
            return "redirect:/detay/kitap/" + kitapId + "?eklendi=true";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/detay/kitap/" + kitapId + "?hata=true";
        }
    }
}