package org.example.yazlab2.Varliklar;
import jakarta.persistence.*;

@Entity
@Table(name = "kullanici")

public class Kullanici
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kullanici_adi", nullable = false, unique = true)
    private String kullaniciAdi;

    @Column(name = "sifre", nullable = false)
    private String sifre;

    @Column(name = "isim")
    private String isim;

    @Column(name = "soyisim")
    private String soyisim;

    @Column(name = "biyografi", length = 500)
    private String biyografi;

    @Column(name = "avatar")
    private String avatar;


    public String getAvatar()
    {
        return avatar;
    }
    public void setAvatar(String avatar)
    {
        this.avatar = avatar;
    }

    public String getIsim()
    {
        return isim;
    }
    public void setIsim(String isim)
    {
        this.isim = isim;
    }

    public String getSoyisim()
    {
        return soyisim;
    }
    public void setSoyisim(String soyisim)
    {
        this.soyisim = soyisim;
    }

    public String getBiyografi()
    {
        return biyografi;
    }
    public void setBiyografi(String biyografi)
    {
        this.biyografi = biyografi;
    }

    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }
    public String getKullaniciAdi()
    {
        return kullaniciAdi;
    }
    public void setKullaniciAdi(String kullaniciAdi)
    {
        this.kullaniciAdi = kullaniciAdi;
    }
    public String getSifre()
    {
        return sifre;
    }
    public void setSifre(String sifre)
    {
        this.sifre = sifre;
    }
}