package org.example.yazlab2.Varliklar;

import jakarta.persistence.*;

@Entity
@Table(name = "icerik")
public class Icerik
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "api_id", unique = true)
    private String apiId;

    @Column(name = "baslik", length = 500)
    private String baslik;

    @Column(name = "tur")
    private String tur;

    @Column(name = "poster_url", length = 2048)
    private String posterUrl;

    @Column(name = "puan")
    private Double puan;

    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public String getApiId()
    {
        return apiId;
    }
    public void setApiId(String apiId)
    {
        this.apiId = apiId;
    }

    public String getBaslik()
    {
        return baslik;
    }
    public void setBaslik(String baslik)
    {
        this.baslik = baslik;
    }

    public String getTur()
    {
        return tur;
    }
    public void setTur(String tur)
    {
        this.tur = tur;
    }

    public String getPosterUrl()
    {
        return posterUrl;
    }
    public void setPosterUrl(String posterUrl)
    {
        this.posterUrl = posterUrl;
    }

    public Double getPuan()
    {
        return puan;
    }
    public void setPuan(Double puan)
    {
        this.puan = puan;
    }
}