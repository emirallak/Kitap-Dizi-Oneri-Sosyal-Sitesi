package org.example.yazlab2.Depo;

import org.example.yazlab2.Varliklar.Kullanici;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface KullaniciDepo extends JpaRepository<Kullanici, Long> {

    Optional<Kullanici> findByKullaniciAdi(String kullaniciAdi);
    @Query("SELECT k FROM Kullanici k WHERE " + "LOWER(k.kullaniciAdi) LIKE LOWER(:sorgu) OR " + "LOWER(COALESCE(k.isim, '')) LIKE LOWER(:sorgu) OR " + "LOWER(COALESCE(k.soyisim, '')) LIKE LOWER(:sorgu)")
    List<Kullanici> kullaniciArama(@Param("sorgu") String sorgu);
}