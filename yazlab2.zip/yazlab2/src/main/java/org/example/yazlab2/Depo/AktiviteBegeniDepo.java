package org.example.yazlab2. Depo;

import org.example. yazlab2.Varliklar.AktiviteBegeni;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework. data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AktiviteBegeniDepo extends JpaRepository<AktiviteBegeni, Long>
{

    boolean existsByAktiviteAndKullanici(KullaniciIcerik aktivite, Kullanici kullanici);
    long countByAktivite(KullaniciIcerik aktivite);
    Optional<AktiviteBegeni> findByAktiviteAndKullanici(KullaniciIcerik aktivite, Kullanici kullanici);
}