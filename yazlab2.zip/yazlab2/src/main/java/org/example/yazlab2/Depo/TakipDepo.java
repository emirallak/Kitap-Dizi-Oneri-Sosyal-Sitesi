package org.example.yazlab2.Depo;

import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.Takip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TakipDepo extends JpaRepository<Takip, Long> {

    Optional<Takip> findByTakipEdenAndTakipEdilen(Kullanici takipEden, Kullanici takipEdilen);
    @Query("SELECT t.takipEdilen FROM Takip t WHERE t.takipEden = :kullanici")
    List<Kullanici> findAllTakipEdilenByTakipEden(@Param("kullanici") Kullanici kullanici);
    long countByTakipEdilen(Kullanici kullanici);
    long countByTakipEden(Kullanici kullanici);
}