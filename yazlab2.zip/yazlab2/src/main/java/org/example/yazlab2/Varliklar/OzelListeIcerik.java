package org.example.yazlab2.Varliklar;

import jakarta.persistence.*;
import java. time.LocalDateTime;

@Entity
public class OzelListeIcerik
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ozel_liste_id")
    private OzelListe ozelListe;

    @ManyToOne
    @JoinColumn(name = "icerik_id")
    private Icerik icerik;

    private LocalDateTime eklenmeTarihi;

    @PrePersist
    protected void onCreate()
    {
        eklenmeTarihi = LocalDateTime.now();
    }


    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public OzelListe getOzelListe()
    {
        return ozelListe;
    }
    public void setOzelListe(OzelListe ozelListe)
    {
        this.ozelListe = ozelListe;
    }

    public Icerik getIcerik()
    {
        return icerik;
    }
    public void setIcerik(Icerik icerik)
    {
        this.icerik = icerik;
    }

    public LocalDateTime getEklenmeTarihi()
    {
        return eklenmeTarihi;
    }
    public void setEklenmeTarihi(LocalDateTime eklenmeTarihi)
    {
        this.eklenmeTarihi = eklenmeTarihi;
    }
}