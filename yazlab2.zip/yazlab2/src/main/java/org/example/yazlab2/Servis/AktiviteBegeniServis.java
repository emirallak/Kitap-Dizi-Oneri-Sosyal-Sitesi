package org.example.yazlab2.Servis;

import org.example.yazlab2. Depo.AktiviteBegeniDepo;
import org. example.yazlab2.Varliklar.AktiviteBegeni;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AktiviteBegeniServis
{

    private final AktiviteBegeniDepo aktiviteBegeniDepo;
    private final KullaniciIcerikServis kullaniciIcerikServis;

    public AktiviteBegeniServis(AktiviteBegeniDepo aktiviteBegeniDepo, KullaniciIcerikServis kullaniciIcerikServis)
    {
        this.aktiviteBegeniDepo = aktiviteBegeniDepo;
        this.kullaniciIcerikServis = kullaniciIcerikServis;
    }


    @Transactional
    public boolean begeniDegistir(Long aktiviteId, Kullanici kullanici) {
        KullaniciIcerik aktivite = kullaniciIcerikServis.aktiviteBul(aktiviteId);


        if (aktiviteBegeniDepo.existsByAktiviteAndKullanici(aktivite, kullanici)) {

            AktiviteBegeni begeni = aktiviteBegeniDepo.findByAktiviteAndKullanici(aktivite, kullanici).orElseThrow(() -> new RuntimeException("Beğeni bulunamadı"));
            aktiviteBegeniDepo.delete(begeni);
            return false;
        }
        else
        {
            AktiviteBegeni yeniBegeni = new AktiviteBegeni(aktivite, kullanici);
            aktiviteBegeniDepo.save(yeniBegeni);
            return true;
        }
    }


    public long begeniSayisi(KullaniciIcerik aktivite)
    {
        return aktiviteBegeniDepo.countByAktivite(aktivite);
    }

    public boolean kullaniciBegenmis(KullaniciIcerik aktivite, Kullanici kullanici)
    {
        return aktiviteBegeniDepo.existsByAktiviteAndKullanici(aktivite, kullanici);
    }
}