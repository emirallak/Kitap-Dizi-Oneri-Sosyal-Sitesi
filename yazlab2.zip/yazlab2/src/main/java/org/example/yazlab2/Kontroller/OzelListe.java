package org.example.yazlab2. Kontroller;

import org. example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Servis.OzelListeServis;
import org.example.yazlab2. Varliklar.Kullanici;
import org.example. yazlab2.Varliklar.OzelListeIcerik;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream. Collectors;

@Controller
public class OzelListe
{

    private final OzelListeServis ozelListeServis;
    private final KullaniciServis kullaniciServis;

    public OzelListe(OzelListeServis ozelListeServis, KullaniciServis kullaniciServis) {
        this.ozelListeServis = ozelListeServis;
        this.kullaniciServis = kullaniciServis;
    }


    @GetMapping("/ozel-listeler")
    public String ozelListeler(Authentication authentication, Model model) {
        Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
        List<org.example.yazlab2.Varliklar.OzelListe> listeler = ozelListeServis.kullaniciListeleriGetir(kullanici);
        model.addAttribute("listeler", listeler);
        return "ozel_listeler";
    }


    @PostMapping("/ozel-liste/olustur")
    public String listeOlustur(@RequestParam("listeAdi") String listeAdi, @RequestParam(value = "aciklama", required = false) String aciklama, Authentication authentication) {
        Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
        ozelListeServis.listeOlustur(kullanici, listeAdi, aciklama);
        return "redirect:/ozel-listeler? olusturuldu=true";
    }


    @GetMapping("/ozel-liste/{id}")
    public String listeDetay(@PathVariable("id") Long id, Model model, Authentication authentication)
    {
        org.example.yazlab2.Varliklar. OzelListe liste = ozelListeServis.listeGetir(id);

        if (liste == null)
        {
            return "redirect:/ozel-listeler? hata=bulunamadi";
        }


        Kullanici kullanici = kullaniciServis. kullaniciBul(authentication. getName());

        if (!liste. getKullanici().getId(). equals(kullanici.getId()))
        {
            return "redirect:/ozel-listeler?hata=yetkisiz";
        }

        List<OzelListeIcerik> icerikler = ozelListeServis.listeIcerikleriGetir(liste);
        model.addAttribute("liste", liste);
        model.addAttribute("icerikler", icerikler);
        return "ozel_liste_detay";
    }


    @PostMapping("/ozel-liste/ekle")
    public String listeyeEkle(@RequestParam("listeId") Long listeId, @RequestParam("apiId") String apiId, @RequestParam("tur") String tur, @RequestParam("baslik") String baslik, @RequestParam("posterUrl") String posterUrl) {
        try
        {
            ozelListeServis.listeyeIcerikEkle(listeId, apiId, tur, baslik, posterUrl);
            return "redirect:/ozel-liste/" + listeId + "? eklendi=true";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/ozel-liste/" + listeId + "?hata=true";
        }
    }
    @PostMapping("/ozel-liste/icerik-sil/{ozelListeIcerikId}")
    public String listeyeIcerikSil(@PathVariable Long ozelListeIcerikId, @RequestParam("listeId") Long listeId, Authentication authentication) {
        try
        {
            Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
            ozelListeServis.listeyeIcerikSil(ozelListeIcerikId, kullanici);

            return "redirect:/ozel-liste/" + listeId + "?silindi=true";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/ozel-liste/" + listeId + "?hata=true";
        }
    }

    @PostMapping("/ozel-liste/sil/{listeId}")
    public String listeSil(@PathVariable Long listeId, Authentication authentication)
    {
        try
        {
            Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
            ozelListeServis.listeSil(listeId, kullanici);

            return "redirect:/ozel-listeler? silindi=true";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/ozel-listeler?hata=true";
        }
    }

    @GetMapping("/api/kullanici-listeleri")
    @ResponseBody
    public List<Map<String, Object>> kullaniciListeleriApi(Authentication authentication)
    {
        Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
        List<org.example.yazlab2.Varliklar.OzelListe> listeler = ozelListeServis.kullaniciListeleriGetir(kullanici);

        return listeler.stream(). map(liste ->
        {
            Map<String, Object> map = new HashMap<>();
            map. put("id", liste.getId());
            map.put("listeAdi", liste.getListeAdi());
            map.put("icerikSayisi", liste. getIcerikler().size());
            return map;
        }).collect(Collectors.toList());
    }
}