package org.example.yazlab2.DTO;

import java.time.LocalDateTime;

public class YorumDTO {
    private Long id;
    private String kullaniciAdi;
    private String yorumMetni;
    private LocalDateTime tarih;
    private boolean kendiYorumumuz;


    public YorumDTO(Long id, String kullaniciAdi, String yorumMetni, LocalDateTime tarih, boolean kendiYorumumuz)
    {

        this.id = id;
        this.kullaniciAdi = kullaniciAdi;
        this.yorumMetni = yorumMetni;
        this.tarih = tarih;
        this.kendiYorumumuz = kendiYorumumuz;
    }

    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public String getKullaniciAdi()
    {
        return kullaniciAdi;
    }
    public void setKullaniciAdi(String kullaniciAdi)
    {
        this.kullaniciAdi = kullaniciAdi;
    }

    public String getYorumMetni()
    {
        return yorumMetni;
    }
    public void setYorumMetni(String yorumMetni) {
        this.yorumMetni = yorumMetni;
    }

    public LocalDateTime getTarih()
    {
        return tarih;
    }
    public void setTarih(LocalDateTime tarih)
    {
        this.tarih = tarih;
    }

    public boolean isKendiYorumumuz()
    {
        return kendiYorumumuz;
    }
    public void setKendiYorumumuz(boolean kendiYorumumuz)
    {
        this.kendiYorumumuz = kendiYorumumuz;
    }
}