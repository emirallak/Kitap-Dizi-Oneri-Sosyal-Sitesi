package org.example. yazlab2.Servis;

import jakarta.transaction.Transactional;
import org.example.yazlab2.Depo.IcerikDepo;
import org.example.yazlab2. Depo.OzelListeDepo;
import org.example. yazlab2.Depo.OzelListeIcerikDepo;
import org. example.yazlab2.Varliklar. Icerik;
import org.example.yazlab2.Varliklar. Kullanici;
import org. example.yazlab2.Varliklar.OzelListe;
import org.example.yazlab2.Varliklar.OzelListeIcerik;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OzelListeServis
{

    private final OzelListeDepo ozelListeDepo;
    private final OzelListeIcerikDepo ozelListeIcerikDepo;
    private final IcerikDepo icerikDepo;

    public OzelListeServis(OzelListeDepo ozelListeDepo, OzelListeIcerikDepo ozelListeIcerikDepo, IcerikDepo icerikDepo) {
        this.ozelListeDepo = ozelListeDepo;
        this.ozelListeIcerikDepo = ozelListeIcerikDepo;
        this.icerikDepo = icerikDepo;
    }
    public List<OzelListe> kullaniciListeleriGetir(Kullanici kullanici)
    {
        return ozelListeDepo.findByKullaniciOrderByOlusturmaTarihiDesc(kullanici);
    }

    public OzelListe listeOlustur(Kullanici kullanici, String listeAdi, String aciklama)
    {
        OzelListe liste = new OzelListe();
        liste.setKullanici(kullanici);
        liste.setListeAdi(listeAdi);
        liste. setAciklama(aciklama);
        return ozelListeDepo.save(liste);
    }

    public void listeyeIcerikEkle(Long listeId, String apiId, String tur, String baslik, String posterUrl)
    {
        OzelListe liste = ozelListeDepo.findById(listeId).orElseThrow(() -> new RuntimeException("Liste bulunamadı"));

        Icerik icerik = icerikDepo.findByApiId(apiId).orElseGet(() ->
        {
                    Icerik yeniIcerik = new Icerik();
                    yeniIcerik.setApiId(apiId);
                    yeniIcerik.setTur(tur);
                    yeniIcerik.setBaslik(baslik);
                    yeniIcerik.setPosterUrl(posterUrl);
                    return icerikDepo.save(yeniIcerik);
                });


        if (!ozelListeIcerikDepo.existsByOzelListeAndIcerik(liste, icerik))
        {
            OzelListeIcerik listeIcerik = new OzelListeIcerik();
            listeIcerik.setOzelListe(liste);
            listeIcerik.setIcerik(icerik);
            ozelListeIcerikDepo.save(listeIcerik);
        }
    }


    public OzelListe listeGetir(Long listeId)
    {
        return ozelListeDepo.findById(listeId).orElse(null);
    }

    public List<OzelListeIcerik> listeIcerikleriGetir(OzelListe liste)
    {
        return ozelListeIcerikDepo.findByOzelListeOrderByEklenmeTarihiDesc(liste);
    }


    @Transactional
    public void listeyeIcerikSil(Long ozelListeIcerikId, Kullanici kullanici) {
        OzelListeIcerik listeIcerik = ozelListeIcerikDepo.findById(ozelListeIcerikId).orElseThrow(() -> new RuntimeException("Liste içeriği bulunamadı"));
        if (!listeIcerik.getOzelListe().getKullanici(). getId().equals(kullanici.getId()))
        {
            throw new SecurityException("Bu listeyi silme yetkiniz yok.");
        }

        ozelListeIcerikDepo.delete(listeIcerik);
    }

    @Transactional
    public void listeSil(Long listeId, Kullanici kullanici) {
        OzelListe liste = ozelListeDepo.findById(listeId).orElseThrow(() -> new RuntimeException("Liste bulunamadı"));
        if (!liste.getKullanici().getId().equals(kullanici.getId()))
        {
            throw new SecurityException("Bu listeyi silme yetkiniz yok.");
        }
        ozelListeDepo.delete(liste);
    }
}