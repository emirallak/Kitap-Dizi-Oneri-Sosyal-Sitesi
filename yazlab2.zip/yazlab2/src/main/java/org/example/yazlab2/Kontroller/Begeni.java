package org.example.yazlab2.Kontroller;

import org.example.yazlab2.Servis.AktiviteBegeniServis;
import org. example.yazlab2.Servis.KullaniciServis;
import org.example. yazlab2.Varliklar. Kullanici;
import org. springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation. PathVariable;
import org.springframework. web.bind.annotation.PostMapping;

@Controller
public class Begeni
{

    private final AktiviteBegeniServis aktiviteBegeniServis;
    private final KullaniciServis kullaniciServis;

    public Begeni(AktiviteBegeniServis aktiviteBegeniServis, KullaniciServis kullaniciServis)
    {
        this.aktiviteBegeniServis = aktiviteBegeniServis;
        this.kullaniciServis = kullaniciServis;
    }

    @PostMapping("/aktivite/begeni/{aktiviteId}")
    public String begeniToggle(@PathVariable Long aktiviteId, Authentication authentication)
    {
        Kullanici kullanici = kullaniciServis.kullaniciBul(authentication.getName());
        aktiviteBegeniServis.begeniDegistir(aktiviteId, kullanici);

        return "redirect:/";
    }
}