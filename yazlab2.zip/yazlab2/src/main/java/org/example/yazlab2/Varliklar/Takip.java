package org.example.yazlab2.Varliklar;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "takip", uniqueConstraints = {@UniqueConstraint(columnNames = {"takip_eden_id", "takip_edilen_id"})})

public class Takip
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "takip_eden_id", nullable = false)
    private Kullanici takipEden;

    @ManyToOne
    @JoinColumn(name = "takip_edilen_id", nullable = false)
    private Kullanici takipEdilen;

    @Column(name = "tarih")
    private LocalDateTime tarih = LocalDateTime.now();


    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Kullanici getTakipEden()
    {
        return takipEden;
    }
    public void setTakipEden(Kullanici takipEden)
    {
        this.takipEden = takipEden;
    }
    public Kullanici getTakipEdilen()
    {
        return takipEdilen;
    }
    public void setTakipEdilen(Kullanici takipEdilen)
    {
        this.takipEdilen = takipEdilen;
    }
    public LocalDateTime getTarih()
    {
        return tarih;
    }
    public void setTarih(LocalDateTime tarih)
    {
        this.tarih = tarih;
    }
}