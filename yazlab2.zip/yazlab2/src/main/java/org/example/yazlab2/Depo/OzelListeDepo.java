package org.example.yazlab2. Depo;

import org.example. yazlab2.Varliklar. Kullanici;
import org. example.yazlab2.Varliklar.OzelListe;
import org.springframework.data.jpa.repository. JpaRepository;
import org. springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OzelListeDepo extends JpaRepository<OzelListe, Long> {
    List<OzelListe> findByKullaniciOrderByOlusturmaTarihiDesc(Kullanici kullanici);
}