package org.example.yazlab2.Varliklar;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "kullanici_icerik")
public class KullaniciIcerik
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "kullanici_id", nullable = false)
    private Kullanici kullanici;

    @ManyToOne
    @JoinColumn(name = "icerik_id", nullable = false)
    private Icerik icerik;

    @Column(name = "durum")
    private String durum;

    @Column(name = "kullanici_puani")
    private Integer puan;


    @Column(name = "tarih")
    private LocalDateTime tarih;


    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }
    public Kullanici getKullanici()
    {
        return kullanici;
    }
    public void setKullanici(Kullanici kullanici)
    {
        this.kullanici = kullanici;
    }
    public Icerik getIcerik()
    {
        return icerik;
    }
    public void setIcerik(Icerik icerik)
    {
        this.icerik = icerik;
    }
    public String getDurum()
    {
        return durum;
    }
    public void setDurum(String durum)
    {
        this.durum = durum;
    }
    public Integer getPuan()
    {
        return puan;
    }
    public void setPuan(Integer puan)
    {
        this.puan = puan;
    }

    public LocalDateTime getTarih()
    {
        return tarih;
    }
    public void setTarih(LocalDateTime tarih)
    {
        this.tarih = tarih;
    }
}