package org.example.yazlab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Yazlab2Application {

	public static void main(String[] args) {
		SpringApplication.run(Yazlab2Application.class, args);
	}

}
