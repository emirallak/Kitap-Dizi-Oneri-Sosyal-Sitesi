package org.example.yazlab2.DTO;

public class KutuphaneDTO
{
    private Long icerikId;
    private String apiId;
    private String baslik;
    private String posterUrl;
    private Double puan;
    private String durum;
    private String tur;

    public KutuphaneDTO(Long icerikId, String apiId, String baslik, String posterUrl, Double puan, String durum, String tur) {
        this.icerikId = icerikId;
        this.apiId = apiId;
        this.baslik = baslik;
        this.posterUrl = posterUrl;
        this.puan = puan;
        this.durum = durum;
        this.tur = tur;
    }

    public Long getIcerikId()
    {
        return icerikId;
    }
    public void setIcerikId(Long icerikId)
    {
        this.icerikId = icerikId;
    }

    public String getApiId()
    {
        return apiId;
    }

    public void setApiId(String apiId)
    {
        this.apiId = apiId;
    }

    public String getBaslik()
    {
        return baslik;
    }
    public void setBaslik(String baslik)
    {
        this.baslik = baslik;
    }

    public String getPosterUrl()
    {
        return posterUrl;
    }
    public void setPosterUrl(String posterUrl)
    {
        this.posterUrl = posterUrl;
    }

    public Double getPuan()
    {
        return puan;
    }
    public void setPuan(Double puan)
    {
        this.puan = puan;
    }

    public String getDurum()
    {
        return durum;
    }
    public void setDurum(String durum)
    {
        this.durum = durum;
    }

    public String getTur()
    {
        return tur;
    }
    public void setTur(String tur)
    {
        this.tur = tur;
    }


    public String getTemizId()
    {
        if (apiId != null)
        {
            return apiId.replace("FILM_", "").replace("KITAP_", "");
        }
        return "";
    }
}