package org. example.yazlab2.Servis;

import org.example. yazlab2.DTO.GoogleBooksCevabi;
import org. example.yazlab2.DTO.KitapDTO;
import org.springframework.stereotype.Service;
import org.springframework.web. client.RestTemplate;
import java.util.ArrayList;
import java.util.List;

@Service
public class GoogleBooksServis
{

    private final String BASE_URL = "https://www.googleapis.com/books/v1/volumes";

    public List<KitapDTO> kitapAra(String sorgu)
    {
        if (sorgu == null || sorgu.isEmpty())
        {
            return new ArrayList<>();
        }
        String url = BASE_URL + "?q=" + sorgu + "&maxResults=20&langRestrict=tr";
        RestTemplate restTemplate = new RestTemplate();
        try
        {
            GoogleBooksCevabi response = restTemplate.getForObject(url, GoogleBooksCevabi.class);

            if (response != null && response.getItems() != null)
            {
                return response.getItems();
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }


    public List<KitapDTO> populerKitaplariGetir()
    {

        String url = BASE_URL + "?q=subject:fiction&orderBy=relevance&maxResults=12&langRestrict=tr";

        RestTemplate restTemplate = new RestTemplate();
        try
        {
            GoogleBooksCevabi response = restTemplate.getForObject(url, GoogleBooksCevabi.class);

            if (response != null && response.getItems() != null)
            {
                return response.getItems();
            }
        } catch (Exception e)
        {
            System.err.println("Popüler kitaplar çekilemedi: " + e.getMessage());
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public KitapDTO kitapDetayGetir(String id)
    {
        String url = BASE_URL + "/" + id;
        RestTemplate restTemplate = new RestTemplate();
        try
        {
            return restTemplate.getForObject(url, KitapDTO. class);
        } catch (Exception e)
        {
            System.err.println("HATA: Kitap detayı çekilemedi.  ID: " + id);
            e.printStackTrace();
            return null;
        }
    }
}