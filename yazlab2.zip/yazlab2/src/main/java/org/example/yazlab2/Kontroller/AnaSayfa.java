package org.example.yazlab2.Kontroller;

import org.example.yazlab2.DTO.AktiviteDTO;
import org.example.yazlab2.Servis.AktiviteServis;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Varliklar.Kullanici;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AnaSayfa
{

    private final AktiviteServis aktiviteServis;
    private final KullaniciServis kullaniciServis;

    public AnaSayfa(AktiviteServis aktiviteServis, KullaniciServis kullaniciServis)
    {
        this.aktiviteServis = aktiviteServis;
        this.kullaniciServis = kullaniciServis;
    }

    @GetMapping("/")
    public String anaSayfa(Authentication authentication, Model model)
    {
        String kullaniciAdi = authentication.getName();

        Kullanici mevcutKullanici = kullaniciServis.kullaniciBul(kullaniciAdi);
        model.addAttribute("kullaniciAdi", kullaniciAdi);
        List<AktiviteDTO> aktiviteAkisi = aktiviteServis.akisGetir(mevcutKullanici);
        model.addAttribute("aktiviteler", aktiviteAkisi);

        return "anasayfa";
    }
}