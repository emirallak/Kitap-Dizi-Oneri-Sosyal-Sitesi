package org.example.yazlab2.Varliklar;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
public class OzelListe {

    @Id
    @GeneratedValue(strategy = GenerationType. IDENTITY)
    private Long id;

    private String listeAdi;
    private String aciklama;

    @ManyToOne
    @JoinColumn(name = "kullanici_id")
    private Kullanici kullanici;

    @OneToMany(mappedBy = "ozelListe", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OzelListeIcerik> icerikler = new ArrayList<>();

    private LocalDateTime olusturmaTarihi;

    @PrePersist
    protected void onCreate()
    {
        olusturmaTarihi = LocalDateTime.now();
    }


    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public String getListeAdi()
    {
        return listeAdi;
    }
    public void setListeAdi(String listeAdi)
    {
        this.listeAdi = listeAdi;
    }

    public String getAciklama()
    {
        return aciklama;
    }
    public void setAciklama(String aciklama)
    {
        this.aciklama = aciklama;
    }

    public Kullanici getKullanici()
    {
        return kullanici;
    }
    public void setKullanici(Kullanici kullanici)
    {
        this.kullanici = kullanici;
    }

    public List<OzelListeIcerik> getIcerikler()
    {
        return icerikler;
    }
    public void setIcerikler(List<OzelListeIcerik> icerikler)
    {
        this.icerikler = icerikler;
    }

    public LocalDateTime getOlusturmaTarihi()
    {
        return olusturmaTarihi;
    }
    public void setOlusturmaTarihi(LocalDateTime olusturmaTarihi)
    {
        this.olusturmaTarihi = olusturmaTarihi;
    }
}