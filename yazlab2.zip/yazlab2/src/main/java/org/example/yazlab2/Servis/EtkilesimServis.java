package org.example.yazlab2.Servis;
import org.example.yazlab2.Depo.KullaniciIcerikDepo;
import org.example.yazlab2.Varliklar.Icerik;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class EtkilesimServis
{
    private final KullaniciIcerikDepo kullaniciIcerikDepo;
    private final IcerikServis icerikServis;

    public EtkilesimServis(KullaniciIcerikDepo kullaniciIcerikDepo, IcerikServis icerikServis)
    {
        this.kullaniciIcerikDepo = kullaniciIcerikDepo;
        this.icerikServis = icerikServis;
    }

    @Transactional
    public void listeyeEkle(Kullanici kullanici, Long tmdbId, String durum, Integer puan)
    {
        Icerik icerik = icerikServis.filmGetirVeyaKaydet(tmdbId);
        kayitOlusturVeyaGuncelle(kullanici, icerik, durum, puan);
    }


    @Transactional
    public void kitapListeyeEkle(Kullanici kullanici, String googleId, String durum, Integer puan)
    {
        Icerik icerik = icerikServis.kitapGetirVeyaKaydet(googleId);
        kayitOlusturVeyaGuncelle(kullanici, icerik, durum, puan);
    }


    public Integer kullaniciPuaniGetir(Kullanici kullanici, String apiId)
    {
        Optional<Icerik> icerikOpt = icerikServis.icerikBul(apiId);
        if (icerikOpt.isEmpty()) return null;

        Optional<KullaniciIcerik> kayitOpt = kullaniciIcerikDepo.findByKullaniciAndIcerik(kullanici, icerikOpt.get());
        return kayitOpt.map(KullaniciIcerik::getPuan).orElse(null);
    }

    private void kayitOlusturVeyaGuncelle(Kullanici kullanici, Icerik icerik, String durum, Integer puan) {
        Optional<KullaniciIcerik> mevcutEtkilesim = kullaniciIcerikDepo.findByKullaniciAndIcerik(kullanici, icerik);
        KullaniciIcerik kayit;
        if (mevcutEtkilesim.isPresent())
        {
            kayit = mevcutEtkilesim.get();
        }
        else
        {
            kayit = new KullaniciIcerik();
            kayit.setKullanici(kullanici);
            kayit.setIcerik(icerik);
        }

        kayit.setDurum(durum);
        kayit.setTarih(LocalDateTime.now());

        if (puan != null)
        {
            kayit.setPuan(puan);
        }
        else if (mevcutEtkilesim.isEmpty())
        {

            kayit.setPuan(null);
        }
        kullaniciIcerikDepo.save(kayit);
    }
}