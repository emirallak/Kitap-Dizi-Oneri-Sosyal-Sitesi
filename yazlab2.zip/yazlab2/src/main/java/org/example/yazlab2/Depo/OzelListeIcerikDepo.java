package org.example.yazlab2.Depo;

import org.example.yazlab2. Varliklar. Icerik;
import org.example.yazlab2.Varliklar.OzelListe;
import org.example.yazlab2.Varliklar.OzelListeIcerik;
import org.springframework. data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OzelListeIcerikDepo extends JpaRepository<OzelListeIcerik, Long> {
    List<OzelListeIcerik> findByOzelListeOrderByEklenmeTarihiDesc(OzelListe ozelListe);
    Optional<OzelListeIcerik> findByOzelListeAndIcerik(OzelListe ozelListe, Icerik icerik);
    boolean existsByOzelListeAndIcerik(OzelListe ozelListe, Icerik icerik);
}