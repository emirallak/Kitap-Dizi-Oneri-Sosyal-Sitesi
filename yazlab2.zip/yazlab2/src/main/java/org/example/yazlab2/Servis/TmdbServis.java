package org.example.yazlab2. Servis;
import org. example.yazlab2.DTO.FilmDTO;
import org.example.yazlab2. DTO.TmdbCevabi;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util. ArrayList;
import java.util. List;

@Service
public class TmdbServis {

    private final String API_KEY = "5117bdc2b40555258a3a8162d49a57b6";
    private final String BASE_URL = "https://api.themoviedb.org/3";

    public List<FilmDTO> filmAra(String aramaKelimesi) {
        if (aramaKelimesi == null || aramaKelimesi. isEmpty()) {
            return new ArrayList<>();
        }
        String url = BASE_URL + "/search/movie?api_key=" + API_KEY + "&query=" + aramaKelimesi + "&language=tr-TR";
        RestTemplate restTemplate = new RestTemplate();
        try
        {
            TmdbCevabi response = restTemplate.getForObject(url, TmdbCevabi.class);
            if (response != null && response.getResults() != null)
            {
                return response.getResults();
            }
        }
        catch (Exception e)
        {
            e. printStackTrace();
        }
        return new ArrayList<>();
    }


    public List<FilmDTO> yuksekPuanliFilmleriGetir()
    {
        String url = BASE_URL + "/movie/top_rated?api_key=" + API_KEY + "&language=tr-TR&page=1";
        RestTemplate restTemplate = new RestTemplate();
        try
        {
            TmdbCevabi response = restTemplate. getForObject(url, TmdbCevabi.class);
            if (response != null && response.getResults() != null)
            {
                List<FilmDTO> filmler = response.getResults();
                if (filmler.size() > 12)
                {
                    return filmler.subList(0, 12);
                }
                else
                {
                    return filmler;
                }
            }
        } catch (Exception e)
        {
            System.err.println("Yüksek puanlı filmler çekilemedi: " + e.getMessage());
            e.printStackTrace();
        }

        return new ArrayList<>();
    }

    public FilmDTO filmDetayGetir(Long id)
    {
        String url = BASE_URL + "/movie/" + id + "?api_key=" + API_KEY + "&language=tr-TR";
        System.out.println("Gidilen URL: " + url);
        RestTemplate restTemplate = new RestTemplate();
        try
        {
            return restTemplate.getForObject(url, FilmDTO.class);
        } catch (Exception e) {
            System.err.println("--- HATA OLUŞTU ---");
            System.err. println("Film ID: " + id);
            System.err.println("Hata Mesajı: " + e.getMessage());
            e. printStackTrace();
            return null;
        }
    }
}