package org.example. yazlab2. Kontroller;

import org. example.yazlab2.DTO.FilmDTO;
import org.example.yazlab2. DTO.KitapDTO;
import org.example.yazlab2.Servis.GoogleBooksServis;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Servis.TmdbServis;
import org. example.yazlab2.Varliklar.Kullanici;
import org.springframework.security. core.Authentication;
import org. springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web. bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class Arama {

    private final TmdbServis tmdbServis;
    private final GoogleBooksServis googleBooksServis;
    private final KullaniciServis kullaniciServis;

    public Arama(TmdbServis tmdbServis, GoogleBooksServis googleBooksServis, KullaniciServis kullaniciServis)
    {
        this.tmdbServis = tmdbServis;
        this. googleBooksServis = googleBooksServis;
        this. kullaniciServis = kullaniciServis;
    }

    @GetMapping("/ara")
    public String aramaYap(@RequestParam(name = "sorgu", required = false) String sorgu, @RequestParam(name = "tur", defaultValue = "film") String tur, Authentication authentication, Model model)
    {

        Kullanici mevcutKullanici = kullaniciServis.kullaniciBul(authentication. getName());
        model.addAttribute("aktifTur", tur);
        model.addAttribute("yapilanArama", sorgu);


        if (sorgu == null || sorgu.trim().isEmpty())
        {
            if ("film". equals(tur))
            {
                List<FilmDTO> populerFilmler = tmdbServis.yuksekPuanliFilmleriGetir();
                model.addAttribute("filmler", populerFilmler);
                model.addAttribute("kesfetModu", true);
            }
            else if ("kitap".equals(tur))
            {
                List<KitapDTO> populerKitaplar = googleBooksServis.populerKitaplariGetir();
                model. addAttribute("kitaplar", populerKitaplar);
                model.addAttribute("kesfetModu", true);
            }
            else if ("kullanici".equals(tur))
            {
                model. addAttribute("kullanicilar", new ArrayList<>());
                model.addAttribute("kesfetModu", false);
            }
            return "arama";
        }


        if ("kitap".equalsIgnoreCase(tur))
        {
            List<KitapDTO> kitaplar = googleBooksServis.kitapAra(sorgu);
            model.addAttribute("kitaplar", kitaplar);
        }
        else if ("kullanici".equalsIgnoreCase(tur))
        {
            List<Kullanici> kullanicilar = kullaniciServis.kullaniciAra(sorgu, mevcutKullanici);
            model.addAttribute("kullanicilar", kullanicilar);
        }
        else
        {
            List<FilmDTO> filmler = tmdbServis.filmAra(sorgu);
            model.addAttribute("filmler", filmler);
        }


        model.addAttribute("kesfetModu", false);

        return "arama";
    }
}