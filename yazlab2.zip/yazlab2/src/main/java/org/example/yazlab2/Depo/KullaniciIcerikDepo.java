package org.example.yazlab2.Depo;

import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.Icerik;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface KullaniciIcerikDepo extends JpaRepository<KullaniciIcerik, Long> {

    Optional<KullaniciIcerik> findByKullaniciAndIcerik(Kullanici kullanici, Icerik icerik);
    List<KullaniciIcerik> findByKullaniciAndDurum(Kullanici kullanici, String durum);
    List<KullaniciIcerik> findByKullanici(Kullanici kullanici);
    List<KullaniciIcerik> findAllByOrderByTarihDesc();
}