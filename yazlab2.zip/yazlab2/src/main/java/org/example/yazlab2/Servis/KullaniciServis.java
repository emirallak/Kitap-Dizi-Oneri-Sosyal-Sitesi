package org.example.yazlab2.Servis;
import org.example.yazlab2.DTO.KutuphaneDTO;
import org.example.yazlab2.Depo.KullaniciDepo;
import org.example.yazlab2.Depo.KullaniciIcerikDepo;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class KullaniciServis implements UserDetailsService
{

    private final KullaniciDepo kullaniciDepo;
    private final KullaniciIcerikDepo kullaniciIcerikDepo;
    private final PasswordEncoder passwordEncoder;

    public KullaniciServis(KullaniciDepo kullaniciDepo, KullaniciIcerikDepo kullaniciIcerikDepo, PasswordEncoder passwordEncoder)
    {
        this.kullaniciDepo = kullaniciDepo;
        this.kullaniciIcerikDepo = kullaniciIcerikDepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
    {
        Kullanici kullanici = kullaniciDepo.findByKullaniciAdi(username).orElseThrow(() -> new UsernameNotFoundException("Kullanıcı bulunamadı: " + username));
        return org.springframework.security.core.userdetails.User.builder().username(kullanici.getKullaniciAdi()).password(kullanici.getSifre()).roles("USER").build();
    }

    public void kullaniciKaydet(Kullanici kullanici)
    {
        kullaniciDepo.save(kullanici);
    }

    public Kullanici kullaniciBul(String kullaniciAdi)
    {
        return kullaniciDepo.findByKullaniciAdi(kullaniciAdi).orElseThrow(() -> new RuntimeException("Kullanıcı bulunamadı!"));
    }


    public List<Kullanici> kullaniciAra(String sorgu, Kullanici mevcutKullanici)
    {
        String likeSorgu = "%" + sorgu + "%";
        List<Kullanici> sonuclar = kullaniciDepo.kullaniciArama(likeSorgu);


        return sonuclar.stream().filter(k -> !k.getId().equals(mevcutKullanici.getId())).collect(Collectors.toList());
    }

    public void profilGuncelle(String kullaniciAdi, String isim, String soyisim, String biyografi, String avatar)
    {
        Kullanici kullanici = kullaniciBul(kullaniciAdi);
        kullanici.setIsim(isim);
        kullanici.setSoyisim(soyisim);
        kullanici.setBiyografi(biyografi);

        if (avatar != null && !avatar.isEmpty())
        {
            kullanici.setAvatar(avatar);
        }
        kullaniciDepo.save(kullanici);
    }
    public List<KutuphaneDTO> kutuphaneGetir(Kullanici kullanici)
    {
        List<KullaniciIcerik> kayitlar = kullaniciIcerikDepo.findByKullanici(kullanici);
        return kayitlar.stream().map(k -> new KutuphaneDTO(k.getIcerik().getId(), k.getIcerik().getApiId(), k.getIcerik().getBaslik(), k.getIcerik().getPosterUrl(), k.getIcerik().getPuan(), k.getDurum(), k.getIcerik().getTur())).collect(Collectors.toList());
    }
}