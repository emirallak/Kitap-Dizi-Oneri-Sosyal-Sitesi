package org.example.yazlab2.Kontroller;


import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Servis.KullaniciServis;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Giris
{

    private final KullaniciServis kullaniciServis;

    public Giris(KullaniciServis kullaniciServis)
    {
        this.kullaniciServis = kullaniciServis;
    }

    @GetMapping("/login")
    public String girisSayfasi() {
        return "login";
    }

    @GetMapping("/kayit")
    public String kayitSayfasi(Model model) {
        model.addAttribute("kullanici", new Kullanici());
        return "kayit";
    }

    @PostMapping("/kayit")
    public String kayitOl(@ModelAttribute Kullanici kullanici,
                          @RequestParam("sifreTekrar") String sifreTekrar,
                          Model model) {

        if (!kullanici.getSifre().equals(sifreTekrar))
        {
            model.addAttribute("error", "Şifreler eşleşmiyor!");
            return "kayit";
        }
        try
        {
            kullaniciServis.kullaniciKaydet(kullanici);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            model.addAttribute("error", "Kayıt Hatası: " + e.getMessage());
            return "kayit";
        }


        return "redirect:/login?kayitBasarili";
    }
}