package org.example.yazlab2.Kontroller;

import org.example.yazlab2.DTO.KutuphaneDTO;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Servis.TakipServis;
import org.example.yazlab2.Varliklar.Kullanici;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class Profil
{

    private final KullaniciServis kullaniciServis;
    private final TakipServis takipServis;

    public Profil(KullaniciServis kullaniciServis, TakipServis takipServis)
    {
        this.kullaniciServis = kullaniciServis;
        this.takipServis = takipServis;
    }


    @GetMapping("/profil")
    public String kendiProfilSayfasi(Authentication authentication)
    {

        String kullaniciAdi = authentication.getName();
        return "redirect:/profil/" + kullaniciAdi;
    }

    @GetMapping("/profil/{hedefKullaniciAdi}")
    public String profilSayfasi(@PathVariable("hedefKullaniciAdi") String hedefKullaniciAdi,
                                Authentication authentication, Model model) {

        String mevcutKullaniciAdi = authentication.getName();
        Kullanici hedefKullanici = kullaniciServis.kullaniciBul(hedefKullaniciAdi);
        Kullanici mevcutKullanici = kullaniciServis.kullaniciBul(mevcutKullaniciAdi);
        List<KutuphaneDTO> tumListe = kullaniciServis.kutuphaneGetir(hedefKullanici);

        List<KutuphaneDTO> izlenenler = tumListe.stream().filter(k -> "FILM".equals(k.getTur()) && "IZLENDI".equals(k.getDurum())).collect(Collectors.toList());

        List<KutuphaneDTO> izlenecekler = tumListe.stream().filter(k -> "FILM".equals(k.getTur()) && "IZLENECEK".equals(k.getDurum())).collect(Collectors.toList());

        List<KutuphaneDTO> okunanlar = tumListe.stream().filter(k -> "KITAP".equals(k.getTur()) && "OKUNDU".equals(k.getDurum())).collect(Collectors.toList());

        List<KutuphaneDTO> okunacaklar = tumListe.stream().filter(k -> "KITAP".equals(k.getTur()) && "OKUNACAK".equals(k.getDurum())).collect(Collectors.toList());

        boolean takipEdiyor = takipServis.takipEdiyorMu(mevcutKullanici, hedefKullanici);
        boolean kendiProfiliMi = mevcutKullaniciAdi.equals(hedefKullaniciAdi);

        long takipciSayisi = takipServis.takipciSayisiGetir(hedefKullanici);
        long takipEdilenSayisi = takipServis.takipEdilenSayisiGetir(hedefKullanici);


        model.addAttribute("kullanici", hedefKullanici);
        model.addAttribute("kendiProfiliMi", kendiProfiliMi);
        model.addAttribute("takipEdiyor", takipEdiyor);
        model.addAttribute("takipciSayisi", takipciSayisi);
        model.addAttribute("takipEdilenSayisi", takipEdilenSayisi);

        model.addAttribute("izlenenler", izlenenler);
        model.addAttribute("izlenecekler", izlenecekler);
        model.addAttribute("okunanlar", okunanlar);
        model.addAttribute("okunacaklar", okunacaklar);

        return "profil";
    }

    @PostMapping("/profil/takip-et")
    public String takipEtmeIslemi(@RequestParam("hedefKullaniciAdi") String hedefKullaniciAdi,
                                  Authentication authentication) {

        String mevcutKullaniciAdi = authentication.getName();
        Kullanici mevcutKullanici = kullaniciServis.kullaniciBul(mevcutKullaniciAdi);
        Kullanici hedefKullanici = kullaniciServis.kullaniciBul(hedefKullaniciAdi);

        takipServis.takipEtmeDurumuToggle(mevcutKullanici, hedefKullanici);

        return "redirect:/profil/" + hedefKullaniciAdi;
    }

    @PostMapping("/profil/guncelle")
    public String profilGuncelle(@RequestParam("isim") String isim, @RequestParam("soyisim") String soyisim, @RequestParam("biyografi") String biyografi, @RequestParam(value = "avatar", required = false) String avatar, Authentication authentication) {

        String kullaniciAdi = authentication.getName();
        kullaniciServis.profilGuncelle(kullaniciAdi, isim, soyisim, biyografi, avatar);

        return "redirect:/profil/" + kullaniciAdi + "?guncel=true";
    }
}