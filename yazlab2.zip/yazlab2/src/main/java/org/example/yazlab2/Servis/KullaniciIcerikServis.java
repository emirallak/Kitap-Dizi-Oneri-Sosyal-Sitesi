package org.example.yazlab2.Servis;
import org.example.yazlab2.Depo.KullaniciIcerikDepo;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.stereotype.Service;

@Service
public class KullaniciIcerikServis
{
    private final KullaniciIcerikDepo kullaniciIcerikDepo;
    public KullaniciIcerikServis(KullaniciIcerikDepo kullaniciIcerikDepo)
    {
        this.kullaniciIcerikDepo = kullaniciIcerikDepo;
    }

    public KullaniciIcerik aktiviteBul(Long id)
    {
        return kullaniciIcerikDepo.findById(id).orElseThrow(() -> new RuntimeException("Aktivite kaydı bulunamadı: " + id));
    }
}