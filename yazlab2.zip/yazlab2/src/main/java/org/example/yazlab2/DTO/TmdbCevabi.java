package org.example.yazlab2.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TmdbCevabi
{

    private List<FilmDTO> results;

    public List<FilmDTO> getResults()
    {
        return results;
    }

    public void setResults(List<FilmDTO> results)
    {
        this.results = results;
    }


}