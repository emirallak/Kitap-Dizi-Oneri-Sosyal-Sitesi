package org.example.yazlab2.Kontroller;

import org.example.yazlab2.DTO.FilmDTO;
import org.example.yazlab2.Servis.EtkilesimServis;
import org.example.yazlab2.Servis.KullaniciServis;
import org.example.yazlab2.Servis.TmdbServis;
import org.example.yazlab2.Varliklar.Kullanici;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Detay
{

    private final TmdbServis tmdbServis;
    private final EtkilesimServis etkilesimServis;
    private final KullaniciServis kullaniciServis;

    public Detay(TmdbServis tmdbServis, EtkilesimServis etkilesimServis, KullaniciServis kullaniciServis)
    {
        this.tmdbServis = tmdbServis;
        this.etkilesimServis = etkilesimServis;
        this.kullaniciServis = kullaniciServis;
    }

    @GetMapping("/detay/film/{id}")
    public String filmDetay(@PathVariable("id") Long id, Model model, Authentication authentication)
    {
        FilmDTO film = tmdbServis.filmDetayGetir(id);

        if (film != null)
        {
            model.addAttribute("film", film);


            if (authentication != null)
            {
                String kullaniciAdi = authentication.getName();
                Kullanici kullanici = kullaniciServis.kullaniciBul(kullaniciAdi);


                String apiId = "FILM_" + id;
                Integer kullaniciPuani = etkilesimServis.kullaniciPuaniGetir(kullanici, apiId);

                model.addAttribute("kullaniciPuani", kullaniciPuani);
            }

            return "detay";
        }
        return "redirect:/ara";
    }

    @PostMapping("/detay/ekle")
    public String listeyeEkle(@RequestParam("filmId") Long filmId, @RequestParam("durum") String durum, @RequestParam(value = "puan", required = false) Integer puan, Authentication authentication) {

        try
        {

            String kullaniciAdi = authentication.getName();
            Kullanici kullanici = kullaniciServis.kullaniciBul(kullaniciAdi);

            etkilesimServis.listeyeEkle(kullanici, filmId, durum, puan);

            return "redirect:/detay/film/" + filmId + "?eklendi=true";

        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "redirect:/detay/film/" + filmId + "?hata=true";
        }
    }
}