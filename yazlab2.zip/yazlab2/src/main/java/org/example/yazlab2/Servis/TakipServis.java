package org.example.yazlab2.Servis;

import org.example.yazlab2.Depo.TakipDepo;
import org.example.yazlab2.Varliklar.Kullanici;
import org.example.yazlab2.Varliklar.Takip;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TakipServis
{

    private final TakipDepo takipDepo;
    public TakipServis(TakipDepo takipDepo)
    {
        this.takipDepo = takipDepo;
    }
    @Transactional
    public boolean takipEtmeDurumuToggle(Kullanici takipEden, Kullanici takipEdilen)
    {
        Optional<Takip> mevcutTakip = takipDepo.findByTakipEdenAndTakipEdilen(takipEden, takipEdilen);

        if (mevcutTakip.isPresent())
        {
            takipDepo.delete(mevcutTakip.get());
            return false;
        } else
        {
            Takip yeniTakip = new Takip();
            yeniTakip.setTakipEden(takipEden);
            yeniTakip.setTakipEdilen(takipEdilen);
            takipDepo.save(yeniTakip);
            return true;
        }
    }


    public List<Long> takipEdilenKullaniciIdleriniGetir(Kullanici takipEden)
    {

        List<Kullanici> takipEdilenler = takipDepo.findAllTakipEdilenByTakipEden(takipEden);

        return takipEdilenler.stream().map(Kullanici::getId).collect(Collectors.toList());
    }

    public long takipciSayisiGetir(Kullanici kullanici)
    {
        return takipDepo.countByTakipEdilen(kullanici);
    }


    public long takipEdilenSayisiGetir(Kullanici kullanici)
    {
        return takipDepo.countByTakipEden(kullanici);
    }


    public boolean takipEdiyorMu(Kullanici takipEden, Kullanici takipEdilen)
    {
        return takipDepo.findByTakipEdenAndTakipEdilen(takipEden, takipEdilen).isPresent();
    }
}