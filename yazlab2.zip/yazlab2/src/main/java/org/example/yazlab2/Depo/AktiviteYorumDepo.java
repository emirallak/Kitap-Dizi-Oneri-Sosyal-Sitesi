package org.example.yazlab2.Depo;

import org.example.yazlab2.Varliklar.AktiviteYorum;
import org.example.yazlab2.Varliklar.KullaniciIcerik;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AktiviteYorumDepo extends JpaRepository<AktiviteYorum, Long> {
    List<AktiviteYorum> findByAktiviteOrderByTarihAsc(KullaniciIcerik aktivite);
    List<AktiviteYorum> findAllByOrderByTarihDesc();
}