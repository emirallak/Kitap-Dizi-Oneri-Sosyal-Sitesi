package org.example.yazlab2.Depo;

import org.example.yazlab2.Varliklar.Icerik;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface IcerikDepo extends JpaRepository<Icerik, Long> {

    Optional<Icerik> findByApiId(String apiId);
}