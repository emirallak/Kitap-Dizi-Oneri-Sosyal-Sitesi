package org.example.yazlab2.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KitapDTO {

    private String id;

    @JsonProperty("volumeInfo")
    private VolumeInfo volumeInfo;


    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class VolumeInfo {
        public String title;
        public List<String> authors;
        public String description;
        public Integer pageCount;
        public ImageLinks imageLinks;
        public Double averageRating;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ImageLinks
    {
        public String thumbnail;
    }

    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }

    public String getBaslik()
    {
        if (volumeInfo != null)
        {
            return volumeInfo.title;
        } else
        {
            return "Başlıksız";
        }
    }

    public String getYazar() {
        if (volumeInfo != null && volumeInfo.authors != null && !volumeInfo.authors.isEmpty())
        {
            return String.join(", ", volumeInfo.authors);
        }
        return "Yazar Bilinmiyor";
    }

    public String getOzet()
    {
        if (volumeInfo != null)
        {
            return volumeInfo.description;
        } else
        {
            return "Özet yok. ";
        }
    }
    public Integer getSayfaSayisi()
    {
        if (volumeInfo != null)
        {
            return volumeInfo.pageCount;
        }
        else
        {
            return 0;
        }
    }

    public Double getPuan()
    {
        if (volumeInfo != null && volumeInfo.averageRating != null) {
            return volumeInfo.averageRating;
        } else {
            return 0.0;
        }
    }

    public String getKapakUrl()
    {
        if (volumeInfo != null && volumeInfo.imageLinks != null && volumeInfo.imageLinks.thumbnail != null)
        {
            return volumeInfo.imageLinks.thumbnail.replace("http://", "https://");
        }
        return "https://via.placeholder.com/128x196?text=Kapak+Yok";
    }
}