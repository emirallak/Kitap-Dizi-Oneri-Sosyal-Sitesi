package org.example.yazlab2.Servis;

import org.example.yazlab2.Depo.IcerikDepo;
import org.example.yazlab2.DTO.FilmDTO;
import org.example.yazlab2.DTO.KitapDTO;
import org.example.yazlab2.Varliklar.Icerik;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Service
public class IcerikServis {

    private final IcerikDepo icerikDepo;
    private final TmdbServis tmdbServis;
    private final GoogleBooksServis googleBooksServis;

    public IcerikServis(IcerikDepo icerikDepo, TmdbServis tmdbServis, GoogleBooksServis googleBooksServis)
    {
        this.icerikDepo = icerikDepo;
        this.tmdbServis = tmdbServis;
        this.googleBooksServis = googleBooksServis;
    }

    @Transactional
    public Icerik filmGetirVeyaKaydet(Long tmdbId) {
        String apiId = "FILM_" + tmdbId;
        Optional<Icerik> mevcutIcerik = icerikDepo.findByApiId(apiId);
        if (mevcutIcerik.isPresent()) return mevcutIcerik.get();

        FilmDTO filmDTO = tmdbServis.filmDetayGetir(tmdbId);
        if (filmDTO == null) throw new RuntimeException("Film bulunamadı: " + tmdbId);

        Icerik yeniIcerik = new Icerik();
        yeniIcerik.setApiId(apiId);
        yeniIcerik.setBaslik(filmDTO.getBaslik());
        yeniIcerik.setTur("FILM");
        yeniIcerik.setPosterUrl(filmDTO.getTamPosterUrl());
        yeniIcerik.setPuan(filmDTO.getPuan() != null ? filmDTO.getPuan() : 0.0);
        return icerikDepo.save(yeniIcerik);
    }


    @Transactional
    public Icerik kitapGetirVeyaKaydet(String googleId)
    {
        String apiId = "KITAP_" + googleId;
        Optional<Icerik> mevcutIcerik = icerikDepo.findByApiId(apiId);
        if (mevcutIcerik.isPresent()) return mevcutIcerik.get();

        KitapDTO kitapDTO = googleBooksServis.kitapDetayGetir(googleId);
        if (kitapDTO == null) throw new RuntimeException("Kitap bulunamadı: " + googleId);

        Icerik yeniIcerik = new Icerik();
        yeniIcerik.setApiId(apiId);
        yeniIcerik.setBaslik(kitapDTO.getBaslik());
        yeniIcerik.setTur("KITAP");
        yeniIcerik.setPosterUrl(kitapDTO.getKapakUrl());
        yeniIcerik.setPuan(kitapDTO.getPuan());
        return icerikDepo.save(yeniIcerik);
    }


    public Optional<Icerik> icerikBul(String apiId)
    {
        return icerikDepo.findByApiId(apiId);
    }
}