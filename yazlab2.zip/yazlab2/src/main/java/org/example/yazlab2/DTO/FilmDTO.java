package org.example.yazlab2.DTO;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FilmDTO {

    private Long id;

    @JsonProperty("title")
    private String baslik;

    @JsonProperty("overview")
    private String ozet;

    @JsonProperty("release_date")
    private String vizyonTarihi;

    @JsonProperty("poster_path")
    private String posterYolu;

    @JsonProperty("vote_average")
    private Double puan;

    @JsonProperty("runtime")
    private Integer sure;

    public Long getId()
    {
        return id;
    }
    public void setId(Long id)
    {
        this.id = id;
    }

    public String getBaslik()
    {
        return baslik;
    }
    public void setBaslik(String baslik)
    {
        this.baslik = baslik;
    }

    public String getOzet()
    {
        return ozet;
    }
    public void setOzet(String ozet)
    {
        this.ozet = ozet;
    }

    public String getVizyonTarihi()
    {
        return vizyonTarihi;
    }
    public void setVizyonTarihi(String vizyonTarihi)
    {
        this.vizyonTarihi = vizyonTarihi;
    }

    public String getPosterYolu()
    {
        return posterYolu;
    }
    public void setPosterYolu(String posterYolu)
    {
        this.posterYolu = posterYolu;
    }


    public Double getPuan()
    {
        return puan;
    }
    public void setPuan(Double puan)
    {
        this.puan = puan;
    }

    public Integer getSure()
    {
        return sure;
    }
    public void setSure(Integer sure)
    {
        this.sure = sure;
    }


    public String getTamPosterUrl()
    {
        if (posterYolu != null && !posterYolu.isEmpty())
        {
            return "https://image.tmdb.org/t/p/w500" + posterYolu;
        }
        return "https://via.placeholder.com/500x750?text=Resim+Yok";
    }
}