package org.example.yazlab2. Servis;

import org.example.yazlab2. Depo.KullaniciIcerikDepo;
import org.example. yazlab2. Depo.AktiviteYorumDepo;
import org.example.yazlab2. Depo.TakipDepo;
import org.example.yazlab2. DTO.AktiviteDTO;
import org.example.yazlab2. Varliklar. Kullanici;
import org. example.yazlab2. Varliklar.KullaniciIcerik;
import org.example.yazlab2.Varliklar.AktiviteYorum;
import org.springframework.stereotype.Service;

import java.util. Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class AktiviteServis {

    private final KullaniciIcerikDepo kullaniciIcerikDepo;
    private final AktiviteYorumDepo aktiviteYorumDepo;
    private final TakipDepo takipDepo;
    private final AktiviteBegeniServis aktiviteBegeniServis;

    public AktiviteServis(KullaniciIcerikDepo kullaniciIcerikDepo, AktiviteYorumDepo aktiviteYorumDepo, TakipDepo takipDepo, AktiviteBegeniServis aktiviteBegeniServis)
    {
        this.kullaniciIcerikDepo = kullaniciIcerikDepo;
        this.aktiviteYorumDepo = aktiviteYorumDepo;
        this.takipDepo = takipDepo;
        this.aktiviteBegeniServis = aktiviteBegeniServis;
    }

    public KullaniciIcerik aktiviteBul(Long id)
    {
        return kullaniciIcerikDepo.findById(id).orElseThrow(() -> new RuntimeException("Aktivite kaydı bulunamadı: " + id));
    }

    public List<AktiviteDTO> akisGetir(Kullanici mevcutKullanici) {
        List<Long> takipEdilenIdler = takipDepo.findAllTakipEdilenByTakipEden(mevcutKullanici). stream().map(Kullanici::getId).collect(Collectors.toList());
        takipEdilenIdler.add(mevcutKullanici.getId());
        List<KullaniciIcerik> tumKayitlar = kullaniciIcerikDepo.findAllByOrderByTarihDesc();
        List<AktiviteYorum> tumAktiviteYorumlari = aktiviteYorumDepo.findAllByOrderByTarihDesc();

        Stream<AktiviteDTO> listelemeAktiviteleri = tumKayitlar.stream().filter(k -> k.getKullanici() != null && takipEdilenIdler.contains(k.getKullanici().getId())).map(kayit -> mapKullaniciIcerikToAktiviteDTO(kayit, mevcutKullanici));

        Stream<AktiviteDTO> yorumAktiviteleri = tumAktiviteYorumlari. stream().filter(y -> y.getYorumuYapan() != null && takipEdilenIdler.contains(y.getYorumuYapan().getId())). map(yorum -> mapAktiviteYorumToAktiviteDTO(yorum, mevcutKullanici));

        return Stream.concat(listelemeAktiviteleri, yorumAktiviteleri).filter(java.util.Objects::nonNull).sorted(Comparator.comparing(AktiviteDTO::getTarih, Comparator.nullsLast(Comparator. reverseOrder()))).limit(15).collect(Collectors.toList());
    }


    public AktiviteDTO mapAktiviteYorumToAktiviteDTO(AktiviteYorum aktiviteYorum, Kullanici mevcutKullanici)
    {
        if (aktiviteYorum == null || aktiviteYorum.getYorumuYapan() == null || aktiviteYorum.getAktivite() == null)
        {
            return null;
        }
 KullaniciIcerik anaAktivite = aktiviteYorum.getAktivite();

        long begeniSayisi = aktiviteBegeniServis.begeniSayisi(anaAktivite);
        boolean kullaniciBegenmis = aktiviteBegeniServis.kullaniciBegenmis(anaAktivite, mevcutKullanici);

        return new AktiviteDTO(
                anaAktivite.getId(),
                aktiviteYorum.getYorumuYapan().getKullaniciAdi(),
                aktiviteYorum.getYorumuYapan().getAvatar(),
                anaAktivite.getIcerik().getBaslik(),
                anaAktivite. getIcerik().getPosterUrl(),
                anaAktivite.getIcerik().getTur(),
                anaAktivite.getIcerik().getApiId(),
                "YORUM",
                null,
                aktiviteYorum.getTarih(),
                aktiviteYorum.getYorumMetni(),
                begeniSayisi,
                kullaniciBegenmis
        );
    }

    public AktiviteDTO mapKullaniciIcerikToAktiviteDTO(KullaniciIcerik kayit, Kullanici mevcutKullanici)
    {
        if (kayit == null || kayit.getKullanici() == null || kayit.getIcerik() == null)
        {
            return null;
        }

        long begeniSayisi = aktiviteBegeniServis.begeniSayisi(kayit);
        boolean kullaniciBegenmis = aktiviteBegeniServis.kullaniciBegenmis(kayit, mevcutKullanici);

        return new AktiviteDTO(
                kayit.getId(),
                kayit.getKullanici().getKullaniciAdi(),
                kayit.getKullanici().getAvatar(),
                kayit.getIcerik().getBaslik(),
                kayit. getIcerik().getPosterUrl(),
                kayit.getIcerik().getTur(),
                kayit.getIcerik().getApiId(),
                kayit.getDurum(),
                kayit.getPuan(),
                kayit.getTarih() != null ? kayit.getTarih() : null,
                null,
                begeniSayisi,
                kullaniciBegenmis
        );
    }
}